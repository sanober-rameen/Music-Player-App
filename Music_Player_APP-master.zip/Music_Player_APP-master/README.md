# Music_Player_APP
this is simple Music Player APP,which is design and developed for a Android Phone
